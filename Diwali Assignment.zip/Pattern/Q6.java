import java.util.Scanner;  
public class Q6 
{  
public static void main(String[] args)   
{  
int i, j, n;  
n = 5;  
for (i = 1; i <= n; i++)   
{   
for (j = i; j >= 1; j--)  
{  
System.out.print(j+" ");  
}  
System.out.println();  
}           
}  
}  

/*

1
2 1
3 2 1
4 3 2 1
5 4 3 2 1

*/